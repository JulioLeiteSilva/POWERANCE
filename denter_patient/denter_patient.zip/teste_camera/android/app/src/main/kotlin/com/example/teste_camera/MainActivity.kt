package com.example.teste_camera

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
